-- License System — Supabase (Postgres) Schema
-- Run this once in your Supabase project's SQL Editor (Database > SQL Editor > New query).

create table if not exists admin_users (
    id bigint generated always as identity primary key,
    username text unique not null,
    password_hash text not null,
    created_at timestamptz not null default now()
);

create table if not exists licenses (
    id bigint generated always as identity primary key,
    license_key text unique not null,
    customer_name text,
    hwid text,
    device_model text,
    android_version text,
    app_version text,
    is_trial boolean not null default false,
    expires_at timestamptz,                 -- null = lifetime
    status text not null default 'active' check (status in ('active', 'revoked', 'expired')),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);
create index if not exists idx_licenses_hwid on licenses (hwid);

create table if not exists trial_devices (
    id bigint generated always as identity primary key,
    hwid text unique not null,
    note text,                               -- set = manually blocked by admin; null = an actual trial grant
    used_at timestamptz not null default now()
);

create table if not exists settings (
    setting_key text primary key,
    setting_value text
);
insert into settings (setting_key, setting_value) values
    ('maintenance_mode', '0'),
    ('trial_enabled', '1'),
    ('current_version', '1.0')
on conflict (setting_key) do nothing;

-- Postgres has no MySQL-style "ON UPDATE CURRENT_TIMESTAMP" — this trigger
-- does the same job for licenses.updated_at.
create or replace function set_updated_at()
returns trigger as $$
begin
    new.updated_at = now();
    return new;
end;
$$ language plpgsql;

drop trigger if exists licenses_set_updated_at on licenses;
create trigger licenses_set_updated_at
before update on licenses
for each row execute function set_updated_at();

-- The app never uses Supabase's anon/authenticated keys — every request
-- goes through our own Next.js API routes using the service_role key,
-- which bypasses RLS entirely. Enabling RLS with zero policies here means
-- these tables are completely unreachable via the anon key even if it
-- ever ends up somewhere it shouldn't (e.g. accidentally shipped to the
-- browser) — defense in depth, not required for the app to function.
alter table admin_users enable row level security;
alter table licenses enable row level security;
alter table trial_devices enable row level security;
alter table settings enable row level security;
